<x-app-layout>
    @livewire('main')
    @livewire('porto')
</x-app-layout>
